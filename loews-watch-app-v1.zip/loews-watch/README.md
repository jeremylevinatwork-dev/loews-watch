# Loews Watch — Apple Watch companion for the Loews security-team suite

A small, glanceable watchOS app (v1) that shows the same live data as the
Loews web apps — no separate data, no new backend.

## What it shows

- **Live counts** (from the shared Supabase cloud, project `loews-tracking`):
  - Fobs — total, and how many are broken (the Fobs app's broken-only rule)
  - Radios — total, and how many are In Field
  - Cameras — total, and how many are Offline
  - Packages — total, and how many are Delivered
- **Team statuses** — each team member's name and current status
  (Available / Do Not Disturb / Day Off / Vacation / Touring Properties /
  At Meeting) with the same colored dot the Fobs app uses, and when the
  status was set.
- **Updated time** and a one-tap refresh button. The counts are cached on
  the watch, so the last numbers show at once even offline, then refresh
  in the background.

## How it reads the live data

Direct Supabase REST reads (the publishable key already embedded in the
public Loews web apps — it only reads the rows the web apps read):

- Fobs + team: row `secure-alert-state`
- Radios: row `radio-state`
- Cameras: row `camera-state`
- Packages: row `package-state`

Refresh is stamp-gated, the same pattern the web apps use: a tiny
`select=data->_ts` read per row, and the full row is downloaded only
when its stamp changed. A refresh is usually four tiny reads.

## Install on your watch (from a Mac, one time)

1. Unzip this project on your Mac and open `LoewsWatch.xcodeproj` in Xcode.
2. Plug your iPhone in (the watch must be paired to it) and pick your
   Apple Watch as the run destination (top bar, next to the Run button).
3. In Signing & Capabilities, pick your team (JEREMY LEVIN) — the first
   run asks for the Apple ID password / trust prompt on the watch.
4. Press **Run**. Xcode installs Loews Watch on the watch. It stays
   there and reads the live cloud on its own.

## Build check

GitHub Actions (`.github/workflows/watchos.yml`) builds the watchOS
target unsigned on `macos-latest` on every push — the same CI pattern
as the Influencer Dúo app. A green run means the project compiles.

## Project

- Target: `LoewsWatch`, standalone watchOS app (no iPhone companion
  app needed), watchOS 10.0+, SwiftUI, bundle
  `com.jhnlsecuritytech.loews-watch`.
- Sources: `LoewsWatch/LoewsWatchApp.swift` (entry),
  `LoewsWatch/ContentView.swift` (UI),
  `LoewsWatch/SupabaseClient.swift` (live data + cache).
- Nothing in the existing Loews apps, the portal, or the iOS shell was
  changed for this app.
