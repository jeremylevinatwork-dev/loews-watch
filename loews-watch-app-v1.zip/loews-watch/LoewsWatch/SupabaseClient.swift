import Foundation

// MARK: - Loews live data
// The watch reads the SAME Supabase cloud the Loews web apps read
// (project "loews-tracking", table app_records). The publishable key
// below is the same one already embedded in the public Loews web apps
// on GitHub Pages. It is a publishable/anon key: it can only read the
// rows the web apps read. It is NOT a secret.

private enum SupabaseConfig {
    static let baseURL = "https://qxqrwusaynfqadjfqswe.supabase.co"
    static let publishableKey = "sb_publishable_2ba9yzEA89uqXHJ6v-_cQg_AmwwEfFF"
    static let fobsRow = "secure-alert-state"
    static let radiosRow = "radio-state"
    static let camerasRow = "camera-state"
    static let packagesRow = "package-state"
}

/// One glanceable snapshot: the live counts and the team statuses.
struct LoewsSnapshot: Codable {
    var fobsTotal = 0
    var fobsBroken = 0
    var beaconsTotal = 0
    var radiosTotal = 0
    var radiosInField = 0
    var camerasTotal = 0
    var camerasOffline = 0
    var camerasActive = 0
    var packagesTotal = 0
    var packagesDelivered = 0
    var team: [TeamMember] = []
    var updatedAt: Date?
}

struct TeamMember: Codable, Identifiable {
    var id: String { name }
    let name: String
    /// Resolved status ("Available" when the cloud has none set,
    /// matching the Fobs app's own fallback).
    let status: String
    let statusAt: Date?
}

// MARK: - Cloud row shapes (only the fields the watch needs)

private struct RowResponse<T: Decodable>: Decodable {
    let data: T
}

private struct StampResponse: Decodable {
    let _ts: Int64?
}

/// A record whose fields the watch never reads (counted only).
private struct AnyRecord: Decodable {}

private struct FobsData: Decodable {
    let _ts: Int64?
    let fobs: [FobLite]?
    let beacons: [AnyRecord]?
    let team: [TeamLite]?
}

private struct FobLite: Decodable {
    let status: String?
    let also: [String]?
}

private struct TeamLite: Decodable {
    let name: String
    let status: String?
    let statusAt: String?
}

private struct RadiosData: Decodable {
    let _ts: Int64?
    let radios: [RadioLite]?
}

private struct RadioLite: Decodable {
    let status: String?
}

private struct CamerasData: Decodable {
    let _ts: Int64?
    let cameras: [CameraLite]?
}

private struct CameraLite: Decodable {
    let status: String?
}

private struct PackagesData: Decodable {
    let _ts: Int64?
    let pkgs: [PkgLite]?
}

private struct PkgLite: Decodable {
    let status: String?
}

// MARK: - Store

/// Owns the live snapshot. Shows the cached counts at once, then
/// refreshes in the background. A refresh is stamp-gated, the same
/// pattern the Loews web apps use: a tiny `data->_ts` read per row,
/// and the full row is downloaded only when its stamp changed, so a
/// refresh is usually four tiny reads instead of four big downloads.
@MainActor
final class LoewsStore: ObservableObject {
    @Published private(set) var snapshot = LoewsSnapshot()
    @Published private(set) var isRefreshing = false
    @Published private(set) var lastError: String?

    private let snapshotCacheKey = "loews.watch.snapshot.v1"
    private let stampsCacheKey = "loews.watch.stamps.v1"
    private var stamps: [String: Int64] = [:]
    private let session = URLSession.shared
    private let decoder = JSONDecoder()
    private static let isoFormatter: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    init() {
        loadCache()
    }

    func refresh() async {
        guard !isRefreshing else { return }
        isRefreshing = true
        lastError = nil
        var errors: [String] = []
        if let error = await refreshFobs() { errors.append(error) }
        if let error = await refreshRadios() { errors.append(error) }
        if let error = await refreshCameras() { errors.append(error) }
        if let error = await refreshPackages() { errors.append(error) }
        snapshot.updatedAt = Date()
        saveCache()
        lastError = errors.first
        isRefreshing = false
    }

    // MARK: - Per-row refresh (each returns an error string, or nil)

    private func refreshFobs() async -> String? {
        switch await fetchRowIfChanged(rowId: SupabaseConfig.fobsRow, as: FobsData.self) {
        case .unchanged:
            return nil
        case .failed:
            return "Fobs didn't load"
        case .changed(let data):
            let fobs = data.fobs ?? []
            snapshot.fobsTotal = fobs.count
            snapshot.fobsBroken = fobs.filter(Self.isBroken).count
            snapshot.beaconsTotal = data.beacons?.count ?? 0
            snapshot.team = (data.team ?? []).map { member in
                TeamMember(
                    name: member.name,
                    status: Self.resolvedStatus(member.status),
                    statusAt: Self.parseDate(member.statusAt)
                )
            }
            return nil
        }
    }

    private func refreshRadios() async -> String? {
        switch await fetchRowIfChanged(rowId: SupabaseConfig.radiosRow, as: RadiosData.self) {
        case .unchanged:
            return nil
        case .failed:
            return "Radios didn't load"
        case .changed(let data):
            let radios = data.radios ?? []
            snapshot.radiosTotal = radios.count
            snapshot.radiosInField = radios.filter { $0.status?.contains("In Field") == true }.count
            return nil
        }
    }

    private func refreshCameras() async -> String? {
        switch await fetchRowIfChanged(rowId: SupabaseConfig.camerasRow, as: CamerasData.self) {
        case .unchanged:
            return nil
        case .failed:
            return "Cameras didn't load"
        case .changed(let data):
            let cameras = data.cameras ?? []
            snapshot.camerasTotal = cameras.count
            snapshot.camerasOffline = cameras.filter { $0.status == "Offline" }.count
            snapshot.camerasActive = cameras.filter { $0.status == "Active" }.count
            return nil
        }
    }

    private func refreshPackages() async -> String? {
        switch await fetchRowIfChanged(rowId: SupabaseConfig.packagesRow, as: PackagesData.self) {
        case .unchanged:
            return nil
        case .failed:
            return "Packages didn't load"
        case .changed(let data):
            let pkgs = data.pkgs ?? []
            snapshot.packagesTotal = pkgs.count
            snapshot.packagesDelivered = pkgs.filter { $0.status == "Delivered" }.count
            return nil
        }
    }

    // MARK: - Stamp-gated fetch

    private enum RowFetch<T> {
        case unchanged
        case changed(T)
        case failed
    }

    private func fetchRowIfChanged<T: Decodable>(rowId: String, as type: T.Type) async -> RowFetch<T> {
        // 1. Tiny stamp read. The response is [{"_ts": <ms>}].
        let stamp = await fetchStamp(rowId: rowId)
        if let stamp = stamp, stamps[rowId] == stamp {
            return .unchanged
        }
        // 2. Full row (only when the stamp moved, or the stamp
        //    could not be read — fail safe toward fresh data).
        guard let url = rowURL(rowId: rowId) else { return .failed }
        guard let body = await fetch(url: url) else { return .failed }
        guard let rows = try? decoder.decode([RowResponse<T>].self, from: body),
              let row = rows.first else { return .failed }
        if let stamp = stamp { stamps[rowId] = stamp }
        return .changed(row.data)
    }

    private func fetchStamp(rowId: String) async -> Int64? {
        guard let url = stampURL(rowId: rowId) else { return nil }
        guard let body = await fetch(url: url) else { return nil }
        guard let rows = try? decoder.decode([StampResponse].self, from: body),
              let first = rows.first else { return nil }
        return first._ts
    }

    private func fetch(url: URL) async -> Data? {
        var request = URLRequest(url: url)
        request.setValue(SupabaseConfig.publishableKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(SupabaseConfig.publishableKey)", forHTTPHeaderField: "Authorization")
        do {
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { return nil }
            return data
        } catch {
            return nil
        }
    }

    private func stampURL(rowId: String) -> URL? {
        var comps = URLComponents(string: SupabaseConfig.baseURL + "/rest/v1/app_records")
        comps?.queryItems = [
            URLQueryItem(name: "id", value: "eq.\(rowId)"),
            URLQueryItem(name: "select", value: "data->_ts")
        ]
        return comps?.url
    }

    private func rowURL(rowId: String) -> URL? {
        var comps = URLComponents(string: SupabaseConfig.baseURL + "/rest/v1/app_records")
        comps?.queryItems = [
            URLQueryItem(name: "id", value: "eq.\(rowId)"),
            URLQueryItem(name: "select", value: "data")
        ]
        return comps?.url
    }

    // MARK: - Rules (match the web apps)

    /// The Fobs app's broken-only rule: a fob counts as broken when
    /// its status or any also-mark is Broken, Charger Port Broken,
    /// or Not Able to Charge.
    private static let brokenMarks = ["Broken", "Charger Port Broken", "Not Able to Charge"]

    private static func isBroken(_ fob: FobLite) -> Bool {
        if let status = fob.status, brokenMarks.contains(status) { return true }
        if let also = fob.also, also.contains(where: { brokenMarks.contains($0) }) { return true }
        return false
    }

    /// The Fobs app falls back to "Available" for a member with no
    /// status set (teamStatusMeta returns the first status).
    private static func resolvedStatus(_ status: String?) -> String {
        guard let status = status, !status.isEmpty else { return "Available" }
        return status == "Busy" ? "Do Not Disturb" : status
    }

    private static func parseDate(_ string: String?) -> Date? {
        guard let string = string else { return nil }
        return isoFormatter.date(from: string)
    }

    // MARK: - Cache

    private func loadCache() {
        if let data = UserDefaults.standard.data(forKey: snapshotCacheKey),
           let cached = try? JSONDecoder().decode(LoewsSnapshot.self, from: data) {
            snapshot = cached
        }
        if let data = UserDefaults.standard.data(forKey: stampsCacheKey),
           let cached = try? JSONDecoder().decode([String: Int64].self, from: data) {
            stamps = cached
        }
    }

    private func saveCache() {
        if let data = try? JSONEncoder().encode(snapshot) {
            UserDefaults.standard.set(data, forKey: snapshotCacheKey)
        }
        if let data = try? JSONEncoder().encode(stamps) {
            UserDefaults.standard.set(data, forKey: stampsCacheKey)
        }
    }
}
