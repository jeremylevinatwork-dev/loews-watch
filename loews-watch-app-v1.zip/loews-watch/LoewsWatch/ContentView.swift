import SwiftUI

// MARK: - Loews colors (match the portal: deep navy, gold rule)

private extension Color {
    static let loewsNavyDark = Color(hex: "12264A")
    static let loewsGold = Color(hex: "B8860B")
    static let loewsGoldLight = Color(hex: "D4AF37")

    init(hex: String) {
        let cleaned = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var value: UInt64 = 0
        _ = Scanner(string: cleaned).scanHexInt64(&value)
        let red = Double((value >> 16) & 0xFF) / 255.0
        let green = Double((value >> 8) & 0xFF) / 255.0
        let blue = Double(value & 0xFF) / 255.0
        self.init(red: red, green: green, blue: blue)
    }
}

/// The team-status dot colors, exactly as the Fobs app defines them.
private func statusColor(_ status: String) -> Color {
    switch status {
    case "Available": return Color(hex: "2f855a")
    case "Do Not Disturb": return Color(hex: "B3261E")
    case "Day Off": return Color(hex: "4A5568")
    case "Vacation": return Color(hex: "B7791F")
    case "Touring Properties": return Color(hex: "2B6CB0")
    case "At Meeting": return Color(hex: "6B46C1")
    default: return Color(hex: "2f855a")
    }
}

private func relativeTime(_ date: Date?) -> String? {
    guard let date = date else { return nil }
    let seconds = -date.timeIntervalSinceNow
    if seconds < 60 { return "just now" }
    if seconds < 3600 { return "\(Int(seconds / 60))m ago" }
    if seconds < 86400 { return "\(Int(seconds / 3600))h ago" }
    return "\(Int(seconds / 86400))d ago"
}

private let updatedFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .none
    formatter.timeStyle = .short
    return formatter
}()

// MARK: - Main view

struct ContentView: View {
    @StateObject private var store = LoewsStore()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                header
                if store.snapshot.fobsTotal == 0
                    && store.snapshot.radiosTotal == 0
                    && store.snapshot.camerasTotal == 0
                    && store.snapshot.packagesTotal == 0 {
                    emptyState
                } else {
                    countsGrid
                    teamSection
                }
                footer
            }
            .padding(.horizontal, 6)
        }
        .task {
            await store.refresh()
        }
    }

    // MARK: - Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text("LOEWS SECURITY")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.loewsGoldLight)
                    .tracking(1.5)
                Spacer()
                Button {
                    Task { await store.refresh() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.loewsGoldLight)
                }
                .buttonStyle(.plain)
                .disabled(store.isRefreshing)
            }
            Rectangle()
                .fill(Color.loewsGold)
                .frame(height: 2)
            HStack(spacing: 4) {
                if store.isRefreshing {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .controlSize(.mini)
                    Text("Updating…")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                } else if let updated = store.snapshot.updatedAt {
                    Text("Updated \(updated, formatter: updatedFormatter)")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                } else {
                    Text("Loews Hotels Security")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
        }
    }

    // MARK: - Counts

    private var countsGrid: some View {
        LazyVGrid(
            columns: [GridItem(.flexible()), GridItem(.flexible())],
            spacing: 8
        ) {
            CountCard(
                icon: "sos",
                title: "Fobs",
                value: store.snapshot.fobsTotal,
                detail: "\(store.snapshot.fobsBroken) broken"
            )
            CountCard(
                icon: "antenna.radiowaves.left.and.right",
                title: "Radios",
                value: store.snapshot.radiosTotal,
                detail: "\(store.snapshot.radiosInField) in field"
            )
            CountCard(
                icon: "video.fill",
                title: "Cameras",
                value: store.snapshot.camerasTotal,
                detail: "\(store.snapshot.camerasOffline) offline"
            )
            CountCard(
                icon: "shippingbox.fill",
                title: "Packages",
                value: store.snapshot.packagesTotal,
                detail: "\(store.snapshot.packagesDelivered) delivered"
            )
        }
    }

    // MARK: - Team

    private var teamSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("TEAM")
                .font(.system(size: 12, weight: .bold))
                .foregroundColor(.loewsGoldLight)
                .tracking(1.5)
            ForEach(store.snapshot.team) { member in
                HStack(spacing: 8) {
                    Circle()
                        .fill(statusColor(member.status))
                        .frame(width: 9, height: 9)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(member.name)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(.primary)
                            .lineLimit(1)
                        HStack(spacing: 4) {
                            Text(member.status)
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            if let ago = relativeTime(member.statusAt) {
                                Text("· \(ago)")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    Spacer()
                }
                .padding(.vertical, 2)
            }
        }
    }

    // MARK: - Empty / error state

    private var emptyState: some View {
        VStack(spacing: 8) {
            if store.isRefreshing {
                ProgressView()
                Text("Loading live counts…")
                    .font(.caption)
                    .foregroundColor(.secondary)
            } else if let error = store.lastError {
                Image(systemName: "wifi.exclamationmark")
                    .font(.title3)
                    .foregroundColor(.loewsGold)
                Text(error)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                Button("Retry") {
                    Task { await store.refresh() }
                }
                .font(.caption)
            } else {
                Text("No data yet.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Button("Refresh") {
                    Task { await store.refresh() }
                }
                .font(.caption)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
    }

    // MARK: - Footer

    private var footer: some View {
        VStack(spacing: 2) {
            Rectangle()
                .fill(Color.loewsGold.opacity(0.6))
                .frame(height: 1)
            Text("Power by: NDL systems tech")
                .font(.system(size: 9))
                .foregroundColor(.secondary)
        }
        .padding(.top, 4)
    }
}

// MARK: - Count card

private struct CountCard: View {
    let icon: String
    let title: String
    let value: Int
    let detail: String

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.loewsGoldLight)
                Text(title.uppercased())
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.secondary)
                    .tracking(0.5)
            }
            Text("\(value)")
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(detail)
                .font(.caption2)
                .foregroundColor(.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(9)
        .background(Color.loewsNavyDark)
        .cornerRadius(12)
    }
}
