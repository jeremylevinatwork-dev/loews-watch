import SwiftUI

/// Loews Watch — the Loews security-team suite on Apple Watch.
/// A small, glanceable companion: live counts (fobs, radios, cameras,
/// packages) and the team member statuses, all read from the same
/// Supabase cloud the Loews web apps read. No separate data, no new
/// backend.
@main
struct LoewsWatchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
